
about my website: It is based on a real band called Vacations. They specialise in indie music and they are from Australia.

purpose: To serve as a comprehensive platform that satisfies both the external user's goal and site owner's goal

features: 
- brand name 
- contact and social media information
- about us page
- tour page
- merch page
- easy to navigate menu bar